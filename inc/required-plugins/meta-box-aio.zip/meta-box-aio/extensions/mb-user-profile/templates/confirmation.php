<?php
/**
 * The template file for the confirmation message.
 *
 * @package    Meta Box
 * @subpackage MB User Profile
 */

?>
<div class="rwmb-confirmation"><?php echo wp_kses_post( $data->confirmation ); ?></div>
