<?php

// Silence is golden