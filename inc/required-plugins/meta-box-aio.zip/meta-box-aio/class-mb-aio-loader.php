<?php
/**
 * The plugin loader: load enabled extensions.
 *
 * @package    Meta Box
 * @subpackage Meta Box AIO
 */

class MB_AIO_Loader {
	public function __construct() {
		// Use 'init' hook to make the filter 'mb_aio_extensions' can be used in themes or other plugins that loaded after this plugin.
		// Priority -5  make sure it runs before any required hook required by premium extensions.
		add_action( 'init', array( $this, 'load_premium_extensions' ), -5 );
	}

	public function load_premium_extensions() {
		$option     = get_option( 'meta_box_aio' );
		$extensions = isset( $option['extensions'] ) ? $option['extensions'] : array();
		$extensions = apply_filters( 'mb_aio_extensions', $extensions );
		$extensions = array_unique( $extensions );

		foreach ( $extensions as $extension ) {
			require_once self::get_extension_file( $extension );
		}
	}

	public static function get_extension_file( $extension ) {
		$files = array_merge(
			array(
				$extension => $extension,
			),
			array(
				'meta-box-text-limiter' => 'text-limiter',
				'meta-box-yoast-seo'    => 'mb-yoast-seo',
			)
		);
		$file  = $files[$extension];
		return dirname( __FILE__ ) . "/extensions/$extension/$file.php";
	}
}
